# cjl0372.github.io 
[![](https://img.shields.io/badge/blog-@champyin-red.svg)](http://blog.cjl0.cn)
[![](https://data.jsdelivr.com/v1/package/gh/cjl0372/cjl0372.github.io/badge)](https://www.jsdelivr.com/package/gh/cjl0372/cjl0372.github.io)

>只是一个引导页

2020.8.7搭建

预览图：

[![](https://cdn.jsdelivr.net/gh/cjl0372/cdn@master/cjl0372.github.io.png.png)](https://cjl0372.github.io/)
----

## 网站左下角播放器代码(v1版)
```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cjl0372/cjl0372.github.io@master/APlayer.min.css">  
<div class="aplayer" data-id="3778678" data-server="netease" data-type="playlist" data-fixed="true" data-autoplay="true"   data-volume="0.6" ></div>
<script src="https://cdn.jsdelivr.net/gh/cjl0372/cjl0372.github.io@master/APlayer.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/cjl0372/cjl0372.github.io@master/Meting.min.js"></script>	
```
----

## ~~网站左下角动态看板娘代码(v1版)~~
```html
<script src="https://cdn.jsdelivr.net/npm/jquery/dist/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome/css/font-awesome.min.css"/>
<script src="https://cdn.jsdelivr.net/gh/stevenjoezhang/live2d-widget/autoload.js"></script>
```
----

