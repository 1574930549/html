
/*QQ344285856 www.bdorder.com*/
arr_wx=["13222038314","13062566757","18851607832"];
var wx_index = Math.floor((Math.random()*arr_wx.length));
var bdorderwx = arr_wx[wx_index];var bdimg = arr_wx[wx_index]+".jpg";
var bd_img = "<img src=images/"+bdimg+">";
